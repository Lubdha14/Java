package com.demo.interfaces;

public interface I2 {
	default void m1() {
		System.out.println("in m1 I22222 method");
	}
	void m31();
}
