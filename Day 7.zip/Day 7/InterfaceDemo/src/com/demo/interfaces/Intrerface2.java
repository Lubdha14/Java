package com.demo.interfaces;

public interface Intrerface2 {
	 void m1();
	 void m3();
	 int i=20;

}
