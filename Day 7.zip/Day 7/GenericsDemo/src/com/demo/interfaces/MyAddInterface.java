package com.demo.interfaces;

public interface MyAddInterface<T,F> {
    T add(F x,F y);

}
