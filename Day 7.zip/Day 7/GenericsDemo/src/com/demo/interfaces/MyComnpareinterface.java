package com.demo.interfaces;

public interface MyComnpareinterface<T> {
    T findMax(T x,T y);
}
