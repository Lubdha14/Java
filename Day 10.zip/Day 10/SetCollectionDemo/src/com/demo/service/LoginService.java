package com.demo.service;

public interface LoginService {

	String autheticate(String uname, String pass);

}
