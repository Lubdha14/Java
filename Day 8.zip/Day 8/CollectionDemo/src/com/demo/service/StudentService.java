package com.demo.service;

public interface StudentService {

}
